create view pg_replication_origin_status(local_id, external_id, remote_lsn, local_lsn) as
SELECT local_id,
       external_id,
       remote_lsn,
       local_lsn
FROM pg_show_replication_origin_status() pg_show_replication_origin_status(local_id, external_id, remote_lsn, local_lsn);

alter table pg_replication_origin_status
    owner to postgres;

